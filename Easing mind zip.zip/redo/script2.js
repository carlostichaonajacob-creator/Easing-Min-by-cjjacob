/**
 * Mind Ease - Main JavaScript
 * Handles GSAP animations, scroll interactions, and form validation
 * with improved accessibility and performance
 */

(() => {
  'use strict';

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // GSAP SETUP — Single plugin registration with error handling
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
    console.error('❌ GSAP or ScrollTrigger not loaded');
    return;
  }

  // Register plugins once
  gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // UTILITY FUNCTIONS
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  const select = (selector) => document.querySelector(selector);
  const selectAll = (selector) => document.querySelectorAll(selector);

  // Debounce utility for resize events
  const debounce = (func, wait) => {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  };

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // NAVIGATION — Scroll effect
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  const header = select('#header');
  let lastScroll = 0;

  window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 50) {
      header.classList.add('therapist-nav--scrolled');
    } else {
      header.classList.remove('therapist-nav--scrolled');
    }
    
    lastScroll = currentScroll;
  }, { passive: true });

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // HERO SECTION — Parallax & intro animation
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  const heroBackground = select('.hero-background');
  if (heroBackground) {
    gsap.to(heroBackground, {
      yPercent: 30,
      ease: 'none',
      scrollTrigger: {
        trigger: '.hero',
        start: 'top top',
        end: 'bottom top',
        scrub: true
      }
    });
  }

  // Hero intro animation
  const animateHeroIntro = () => {
    const heroText = select('.hero-text');
    const heroCtas = select('.hero-ctas');
    const trustBadges = select('.trust-badges');

    if (!heroText) return;

    const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

    tl.from(heroText.querySelector('h1'), {
      y: 50,
      opacity: 0,
      duration: 1,
      delay: 0.3
    })
    .from(heroText.querySelector('.subtext'), {
      y: 30,
      opacity: 0,
      duration: 0.8
    }, '-=0.5')
    .from(heroCtas, {
      y: 30,
      opacity: 0,
      duration: 0.8
    }, '-=0.4')
    .from(trustBadges, {
      y: 20,
      opacity: 0,
      duration: 0.8
    }, '-=0.3');
  };

  animateHeroIntro();

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // SCROLL ANIMATIONS — Reusable function
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  const animateOnScroll = (selector, animation = {}) => {
    const elements = selectAll(selector);
    
    elements.forEach((element, index) => {
      gsap.from(element, {
        scrollTrigger: {
          trigger: element,
          start: 'top 85%',
          end: 'bottom 20%',
          toggleActions: 'play none none reverse'
        },
        y: animation.y || 50,
        x: animation.x || 0,
        opacity: 0,
        scale: animation.scale || 1,
        duration: animation.duration || 0.8,
        ease: animation.ease || 'power3.out',
        delay: animation.stagger ? index * 0.15 : 0
      });
    });
  };

  // Apply scroll animations to various elements
  animateOnScroll('.fade-in', { y: 40 });
  animateOnScroll('.slide-in-left', { x: -60, y: 0 });
  animateOnScroll('.slide-in-right', { x: 60, y: 0 });
  animateOnScroll('.scale-in', { scale: 0.9, y: 30 });

  // Service cards stagger
  animateOnScroll('.service-card', { y: 50, stagger: true });

  // Testimonial cards stagger
  animateOnScroll('.testimonial-card', { y: 40, stagger: true });

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // IMAGE HOVER EFFECTS — About section
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  const imageBoxes = selectAll('.about-image-box');
  imageBoxes.forEach(box => {
    const img = box.querySelector('img');
    if (!img) return;

    box.addEventListener('mouseenter', () => {
      gsap.to(img, {
        scale: 1.08,
        duration: 0.6,
        ease: 'power2.out'
      });
    });

    box.addEventListener('mouseleave', () => {
      gsap.to(img, {
        scale: 1,
        duration: 0.6,
        ease: 'power2.out'
      });
    });
  });

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // SMOOTH SCROLL — Navigation links with fallback
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  const smoothScrollTo = (targetElement) => {
    if (!targetElement) return;

    const navHeight = header ? header.offsetHeight : 80;
    
    // Check if ScrollToPlugin is available
    if (typeof gsap.to === 'function' && ScrollToPlugin) {
      gsap.to(window, {
        duration: 1,
        scrollTo: {
          y: targetElement,
          offsetY: navHeight
        },
        ease: 'power3.inOut'
      });
    } else {
      // Fallback to native smooth scroll
      const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - navHeight;
      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
      });
    }
  };

  // Apply smooth scroll to all anchor links
  const navLinks = selectAll('a[href^="#"]');
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('href');
      const targetElement = select(targetId);
      
      if (targetElement) {
        smoothScrollTo(targetElement);
      }
    });
  });

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // CTA BUTTON — "Start Your Journey" button
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  const meetTherapistBtn = select('#meetTherapistBtn');
  if (meetTherapistBtn) {
    meetTherapistBtn.addEventListener('click', () => {
      const bookSection = select('#book');
      if (bookSection) {
        smoothScrollTo(bookSection);
      }
    });
  }

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // FEATURE ITEMS HOVER — About section
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  const featureItems = selectAll('.about-feature-item');
  featureItems.forEach(item => {
    item.addEventListener('mouseenter', () => {
      gsap.to(item, {
        x: 12,
        duration: 0.3,
        ease: 'power2.out'
      });
    });

    item.addEventListener('mouseleave', () => {
      gsap.to(item, {
        x: 0,
        duration: 0.3,
        ease: 'power2.out'
      });
    });
  });

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // SERVICE CARDS — Hover & keyboard interactions
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  const serviceCards = selectAll('.service-card');
  serviceCards.forEach(card => {
    // Mouse hover
    card.addEventListener('mouseenter', () => {
      gsap.to(card, {
        y: -8,
        duration: 0.3,
        ease: 'power2.out'
      });
    });

    card.addEventListener('mouseleave', () => {
      gsap.to(card, {
        y: 0,
        duration: 0.3,
        ease: 'power2.out'
      });
    });

    // Keyboard interaction for accessibility
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        gsap.to(card, {
          y: -6,
          duration: 0.2,
          ease: 'back.out'
        });
        setTimeout(() => {
          gsap.to(card, {
            y: 0,
            duration: 0.2
          });
        }, 200);
      }
    });
  });

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // CTA BUTTON — Services section
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  const ctaButton = select('.cta-button');
  if (ctaButton) {
    ctaButton.addEventListener('mouseenter', () => {
      gsap.to(ctaButton, {
        y: -2,
        duration: 0.24,
        ease: 'power2.out',
        overwrite: 'auto'
      });
    });

    ctaButton.addEventListener('mouseleave', () => {
      gsap.to(ctaButton, {
        y: 0,
        duration: 0.24,
        ease: 'power2.out',
        overwrite: 'auto'
      });
    });
  }

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // CONTACT FORM — Validation & submission with accessibility
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  const form = select('#contactForm');
  const successMessage = select('#successMessage');

  if (form && successMessage) {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Clear previous errors
      selectAll('.contact__error').forEach(error => {
        error.classList.remove('contact__error--visible');
      });

      let isValid = true;

      // Validate name
      const nameInput = select('#name');
      if (!nameInput.value.trim()) {
        select('#nameError').classList.add('contact__error--visible');
        isValid = false;
      }

      // Validate email
      const emailInput = select('#email');
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailInput.value)) {
        select('#emailError').classList.add('contact__error--visible');
        isValid = false;
      }

      // Validate message
      const messageInput = select('#message');
      if (!messageInput.value.trim()) {
        select('#messageError').classList.add('contact__error--visible');
        isValid = false;
      }

      if (isValid) {
        // Disable button
        const button = form.querySelector('.contact__button');
        button.disabled = true;
        button.querySelector('.contact__button-text').textContent = 'Sending...';

        // Simulate sending (in real implementation, send to server)
        setTimeout(() => {
          select('.contact__form-container').style.display = 'none';
          successMessage.classList.add('contact__success--visible');
          
          // Announce to screen readers
          successMessage.setAttribute('aria-live', 'polite');
        }, 800);

        // Log form data (in real implementation, send to server)
        console.log('Form submitted:', {
          name: nameInput.value,
          email: emailInput.value,
          phone: select('#phone').value,
          support: select('#support').value,
          message: messageInput.value
        });
      } else {
        // Focus first error field for accessibility
        const firstError = select('.contact__error--visible');
        if (firstError) {
          const fieldId = firstError.id.replace('Error', '');
          const errorField = select(`#${fieldId}`);
          if (errorField) {
            errorField.focus();
          }
        }
      }
    });

    // Input focus animations with label color change
    const inputs = selectAll('.contact__input, .contact__textarea, .contact__select');
    inputs.forEach(input => {
      input.addEventListener('focus', function() {
        const label = this.previousElementSibling;
        if (label && label.classList.contains('contact__label')) {
          label.style.color = 'var(--therapist-olive)';
        }
      });

      input.addEventListener('blur', function() {
        const label = this.previousElementSibling;
        if (label && label.classList.contains('contact__label')) {
          label.style.color = 'var(--therapist-text-main)';
        }
      });
    });
  }

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // PERFORMANCE — Debounced ScrollTrigger refresh on resize
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  const handleResize = debounce(() => {
    ScrollTrigger.refresh();
  }, 150);

  window.addEventListener('resize', handleResize);

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // INITIALIZATION COMPLETE
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  console.log('✅ Mind Ease animations loaded successfully');
})();